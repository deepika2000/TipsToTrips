import { Component, OnInit } from '@angular/core';
import { EmpService } from '../emp.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-states',
  templateUrl: './states.component.html',
  styleUrls: ['./states.component.css']
})
export class StatesComponent implements OnInit {
  cities : any;
  place : any;
  constructor(private router : Router,private service : EmpService) { 
    this.cities = this.service.states;
    console.log('Inside constructor...',this.cities);
    }

  ngOnInit() { 
  }
  showPlaces(Id : any){
    console.log('Inside Places...','',Id);
    this.service.Places(Id);
  }
}
